#!/bin/bash
cd "$(dirname "$0")"
source venv/bin/activate

# Eski jarayonlarni to'xtatish
lsof -ti :8000 | xargs kill -9 2>/dev/null
pkill -f "cloudflared tunnel" 2>/dev/null

# Mac uxlab qolmasligi uchun
caffeinate -dims &
CAF=$!

# Tunnel (HTTPS manzil)
rm -f /tmp/cf.log
cloudflared tunnel --url http://localhost:8000 > /tmp/cf.log 2>&1 &
CF=$!

echo "Tunnel manzili kutilmoqda (1-2 daqiqagacha)..."
URL=""
for i in $(seq 1 60); do
  URL=$(grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' /tmp/cf.log | head -1)
  [ -n "$URL" ] && break
  sleep 2
done

if [ -z "$URL" ]; then
  echo "Manzil chiqmadi. Internetni tekshirib, qayta urinib ko'ring."
  kill $CF $CAF 2>/dev/null
  exit 1
fi
echo "Manzil: $URL"

# Manzilni .env ga yozish
if grep -q '^BASE_URL=' .env; then
  sed -i '' "s|^BASE_URL=.*|BASE_URL=$URL|" .env
else
  echo "BASE_URL=$URL" >> .env
fi

trap "kill $CF $CAF 2>/dev/null" EXIT
python -m uvicorn app.main:app --port 8000
