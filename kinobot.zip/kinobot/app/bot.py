import logging

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    CallbackQuery,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    MenuButtonWebApp,
    Message,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
    WebAppInfo,
)

from .config import ADMIN_IDS, BASE_URL, BOT_TOKEN, MAX_BOT_FILE, UPLOAD_DIR
from .database import execute, fetch_all, fetch_one, get_setting
from .subscription import subscription_ok

bot = Bot(BOT_TOKEN, session=AiohttpSession(timeout=300))
dp = Dispatcher()
router = Router()
dp.include_router(router)

BOT_INFO = {"username": ""}
ICONS = {"telegram": "✈️", "instagram": "📸", "youtube": "▶️"}


# ---------- yordamchi funksiyalar ----------

def app_kb(path: str = ""):
    """Mini ilovani ochuvchi tugma (faqat HTTPS bo'lsa ishlaydi)."""
    if not BASE_URL.startswith("https://"):
        return None
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="🎬 Kinolarni ochish", web_app=WebAppInfo(url=BASE_URL + path))]]
    )


def phone_kb():
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="📱 Telefon raqamni yuborish", request_contact=True)]],
        resize_keyboard=True,
        one_time_keyboard=True,
    )


async def sub_kb():
    channels = await fetch_all("SELECT * FROM channels WHERE active=1")
    rows = [
        [InlineKeyboardButton(text=f"{ICONS.get(c['kind'], '🔗')} {c['title']}", url=c["url"])]
        for c in channels
    ]
    rows.append([InlineKeyboardButton(text="✅ Tekshirish", callback_data="check_sub")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def upsert_user(u):
    await execute(
        "INSERT INTO users(id, username, first_name) VALUES(?, ?, ?) "
        "ON CONFLICT(id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name",
        (u.id, u.username, u.first_name),
    )


async def gate(user, message: Message) -> bool:
    """Bloklanmaganmi, telefon bergannmi, obuna bo'lganmi: tekshiradi."""
    await upsert_user(user)
    if user.id in ADMIN_IDS:
        return True
    row = await fetch_one("SELECT * FROM users WHERE id=?", (user.id,))
    if row["blocked"]:
        await message.answer("🚫 Siz bloklangansiz.")
        return False
    if not row["phone"]:
        await message.answer(
            "Botdan foydalanish uchun telefon raqamingizni yuboring 👇",
            reply_markup=phone_kb(),
        )
        return False
    if not await subscription_ok(bot, user.id):
        await message.answer(
            "Botdan foydalanish uchun quyidagi kanallarga obuna bo'ling, "
            "so'ng «Tekshirish» tugmasini bosing 👇",
            reply_markup=await sub_kb(),
        )
        return False
    return True


async def send_welcome(message: Message):
    text = await get_setting("welcome_text", "Xush kelibsiz!")
    await message.answer(text, reply_markup=app_kb())


async def send_movie(m: Message, movie: dict):
    caption = f"🎬 {movie['title']}"
    if movie["year"]:
        caption += f" ({movie['year']})"
    if movie["genre"]:
        caption += f"\n🎭 {movie['genre']}"
    if movie["description"]:
        caption += f"\n\n{movie['description']}"
    caption += f"\n\n🔢 Kod: {movie['code']}"
    caption = caption[:1024]

    await execute("UPDATE movies SET views=views+1 WHERE id=?", (movie["id"],))

    try:
        if movie["tg_file_id"]:
            await m.answer_video(movie["tg_file_id"], caption=caption)
            return
        if movie["video_path"]:
            path = UPLOAD_DIR / movie["video_path"]
            if path.exists() and path.stat().st_size <= MAX_BOT_FILE:
                await m.answer("⏳ Kino yuborilmoqda...")
                sent = await m.answer_video(FSInputFile(path), caption=caption, supports_streaming=True)
                if sent.video:
                    await execute(
                        "UPDATE movies SET tg_file_id=? WHERE id=?", (sent.video.file_id, movie["id"])
                    )
                return
    except Exception:
        logging.exception("Kino yuborishda xato")

    # Fayl katta (50 MB dan ortiq) yoki xato bo'ldi: mini ilovaga yo'naltiramiz
    await m.answer(
        caption + "\n\nBu kinoni mini ilovada ko'ring 👇",
        reply_markup=app_kb(f"/?movie={movie['id']}"),
    )


# ---------- handlerlar ----------

@router.message(CommandStart())
async def cmd_start(m: Message):
    if await gate(m.from_user, m):
        await send_welcome(m)


@router.message(F.contact)
async def got_contact(m: Message):
    if m.contact.user_id != m.from_user.id:
        await m.answer("Iltimos, o'zingizning raqamingizni tugma orqali yuboring.")
        return
    await upsert_user(m.from_user)
    phone = m.contact.phone_number
    if not phone.startswith("+"):
        phone = "+" + phone
    await execute("UPDATE users SET phone=? WHERE id=?", (phone, m.from_user.id))
    await m.answer("✅ Raqamingiz qabul qilindi.", reply_markup=ReplyKeyboardRemove())
    if await gate(m.from_user, m):
        await send_welcome(m)


@router.callback_query(F.data == "check_sub")
async def cb_check_sub(c: CallbackQuery):
    await execute("UPDATE users SET links_ok=1 WHERE id=?", (c.from_user.id,))
    if await subscription_ok(bot, c.from_user.id):
        try:
            await c.message.delete()
        except Exception:
            pass
        await send_welcome(c.message)
        await c.answer()
    else:
        await c.answer("❌ Hali hamma kanalga obuna bo'lmadingiz!", show_alert=True)


@router.message(Command("admin"))
async def cmd_admin(m: Message):
    if m.from_user.id not in ADMIN_IDS:
        return
    if not BASE_URL.startswith("https://"):
        await m.answer("BASE_URL .env faylida https:// bilan boshlanishi kerak.")
        return
    kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="⚙️ Admin panel", web_app=WebAppInfo(url=BASE_URL + "/admin"))]]
    )
    await m.answer("Admin panelni ochish:", reply_markup=kb)


@router.message(F.text & ~F.text.startswith("/"))
async def by_code(m: Message):
    if not await gate(m.from_user, m):
        return
    code = m.text.strip()
    movie = await fetch_one(
        "SELECT * FROM movies WHERE lower(code)=lower(?) AND place IN ('bot','both')", (code,)
    )
    if not movie:
        await m.answer("❌ Bunday kodli kino topilmadi.")
        return
    await send_movie(m, movie)


# ---------- ishga tushirish ----------

async def setup_bot():
    me = await bot.get_me()
    BOT_INFO["username"] = me.username
    await bot.delete_webhook(drop_pending_updates=True)
    if BASE_URL.startswith("https://"):
        try:
            await bot.set_chat_menu_button(
                menu_button=MenuButtonWebApp(text="🎬 Kinolar", web_app=WebAppInfo(url=BASE_URL))
            )
        except Exception:
            logging.exception("Menu tugmasini o'rnatib bo'lmadi")
