import asyncio
import logging
import re
import shutil
import uuid
from pathlib import Path
from typing import Optional

from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    File,
    Form,
    HTTPException,
    UploadFile,
)
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel

from .auth import admin_user, current_user
from .bot import BOT_INFO, bot
from .config import ADMIN_IDS, MAX_BOT_FILE, UPLOAD_DIR
from .database import execute, fetch_all, fetch_one, get_setting, set_setting
from .subscription import subscription_ok

router = APIRouter(prefix="/api")

VIDEO_EXT = {".mp4", ".mov", ".webm", ".mkv", ".m4v"}
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp"}


# ---------- yordamchilar ----------

async def save_upload(file: UploadFile, subdir: str, allowed: set) -> str:
    ext = Path(file.filename or "").suffix.lower()
    if ext not in allowed:
        raise HTTPException(400, f"Fayl turi mos emas: {ext or '?'} (ruxsat: {', '.join(sorted(allowed))})")
    name = f"{uuid.uuid4().hex}{ext}"
    dest = UPLOAD_DIR / subdir / name
    with open(dest, "wb") as f:
        await run_in_threadpool(shutil.copyfileobj, file.file, f, 1024 * 1024)
    return f"{subdir}/{name}"


def remove_file(rel):
    if rel:
        try:
            (UPLOAD_DIR / rel).unlink(missing_ok=True)
        except Exception:
            pass


def derive_chat_id(kind: str, url: str, chat_id: str) -> str:
    chat_id = (chat_id or "").strip()
    if chat_id:
        if re.fullmatch(r"-?\d+", chat_id):
            return chat_id
        return chat_id if chat_id.startswith("@") else "@" + chat_id
    if kind == "telegram":
        m = re.search(r"t\.me/([A-Za-z0-9_]{4,})/?$", url.strip())
        if m:
            return "@" + m.group(1)
    return ""


async def user_state(uid: int) -> str:
    if uid in ADMIN_IDS:
        return "ok"
    row = await fetch_one("SELECT * FROM users WHERE id=?", (uid,))
    if row and row["blocked"]:
        return "blocked"
    if not row or not row["phone"]:
        return "need_phone"
    if not await subscription_ok(bot, uid, use_cache=True):
        return "need_sub"
    return "ok"


async def app_user(user=Depends(current_user)):
    state = await user_state(user["id"])
    if state != "ok":
        raise HTTPException(403, state)
    return user


# ---------- mini ilova (foydalanuvchi) ----------

@router.get("/me")
async def me(user=Depends(current_user)):
    state = await user_state(user["id"])
    channels = []
    if state == "need_sub":
        channels = await fetch_all("SELECT kind, title, url FROM channels WHERE active=1")
    return {
        "state": state,
        "is_admin": user["id"] in ADMIN_IDS,
        "bot": BOT_INFO["username"],
        "channels": channels,
    }


@router.post("/check-sub")
async def check_sub(user=Depends(current_user)):
    await execute("UPDATE users SET links_ok=1 WHERE id=?", (user["id"],))
    return {"state": await user_state(user["id"])}


@router.get("/home")
async def home(user=Depends(app_user)):
    banners = await fetch_all(
        "SELECT id, media_path, media_type, link FROM banners WHERE active=1 ORDER BY id DESC"
    )
    movies = await fetch_all(
        "SELECT id, code, title, year, genre, poster_path, views FROM movies "
        "WHERE place IN ('app','both') ORDER BY id DESC LIMIT 500"
    )
    return {"banners": banners, "movies": movies}


@router.get("/movies/{movie_id}")
async def movie_detail(movie_id: int, user=Depends(app_user)):
    m = await fetch_one(
        "SELECT * FROM movies WHERE id=? AND place IN ('app','both')", (movie_id,)
    )
    if not m:
        raise HTTPException(404, "Kino topilmadi")
    await execute("UPDATE movies SET views=views+1 WHERE id=?", (movie_id,))
    return {
        "id": m["id"],
        "code": m["code"],
        "title": m["title"],
        "year": m["year"],
        "genre": m["genre"],
        "description": m["description"],
        "poster": f"/uploads/{m['poster_path']}" if m["poster_path"] else None,
        "video": f"/uploads/{m['video_path']}" if m["video_path"] else None,
    }


# ---------- admin ----------

@router.get("/admin/stats")
async def stats(_=Depends(admin_user)):
    u = await fetch_one(
        "SELECT COUNT(*) AS total, SUM(blocked) AS blocked, "
        "SUM(phone IS NOT NULL) AS with_phone FROM users"
    )
    today = await fetch_one("SELECT COUNT(*) AS c FROM users WHERE date(created_at)=date('now')")
    mv = await fetch_one("SELECT COUNT(*) AS c, SUM(views) AS v FROM movies")
    top = await fetch_all("SELECT title, code, views FROM movies ORDER BY views DESC LIMIT 5")
    return {
        "users": u["total"] or 0,
        "blocked": u["blocked"] or 0,
        "with_phone": u["with_phone"] or 0,
        "today": today["c"],
        "movies": mv["c"] or 0,
        "views": mv["v"] or 0,
        "top": top,
    }


# --- foydalanuvchilar

@router.get("/admin/users")
async def users(q: str = "", page: int = 0, _=Depends(admin_user)):
    like = f"%{q}%"
    where = (
        "WHERE ?='' OR username LIKE ? OR phone LIKE ? OR first_name LIKE ? "
        "OR CAST(id AS TEXT) LIKE ?"
    )
    params = (q, like, like, like, like)
    total = await fetch_one(f"SELECT COUNT(*) AS c FROM users {where}", params)
    items = await fetch_all(
        f"SELECT id, username, first_name, phone, blocked, created_at FROM users {where} "
        "ORDER BY created_at DESC LIMIT 30 OFFSET ?",
        params + (max(page, 0) * 30,),
    )
    return {"total": total["c"], "items": items}


class BlockIn(BaseModel):
    blocked: bool


@router.post("/admin/users/{uid}/block")
async def block_user(uid: int, body: BlockIn, _=Depends(admin_user)):
    await execute("UPDATE users SET blocked=? WHERE id=?", (1 if body.blocked else 0, uid))
    return {"ok": True}


# --- kinolar

@router.get("/admin/movies")
async def admin_movies(_=Depends(admin_user)):
    return await fetch_all(
        "SELECT id, code, title, year, genre, place, views, poster_path FROM movies ORDER BY id DESC"
    )


@router.post("/admin/movies")
async def add_movie(
    code: str = Form(...),
    title: str = Form(...),
    year: str = Form(""),
    genre: str = Form(""),
    description: str = Form(""),
    place: str = Form("both"),
    video: UploadFile = File(...),
    poster: Optional[UploadFile] = File(None),
    _=Depends(admin_user),
):
    code = code.strip()
    title = title.strip()
    if not code or not title:
        raise HTTPException(400, "Kod va nom kerak")
    if place not in ("bot", "app", "both"):
        raise HTTPException(400, "Joylash turi noto'g'ri")
    if await fetch_one("SELECT id FROM movies WHERE lower(code)=lower(?)", (code,)):
        raise HTTPException(400, "Bu kod band, boshqa kod tanlang")

    video_path = await save_upload(video, "videos", VIDEO_EXT)
    poster_path = None
    try:
        if poster is not None and poster.filename:
            poster_path = await save_upload(poster, "posters", IMAGE_EXT)
        if place == "bot" and (UPLOAD_DIR / video_path).stat().st_size > MAX_BOT_FILE:
            raise HTTPException(
                400,
                "Bot orqali faqat 50 MB gacha kino yuboriladi. Katta kino uchun «Bot + Mini ilova» yoki «Faqat mini ilova» tanlang.",
            )
        await execute(
            "INSERT INTO movies(code, title, year, genre, description, place, video_path, poster_path) "
            "VALUES(?,?,?,?,?,?,?,?)",
            (
                code,
                title,
                int(year) if year.strip().isdigit() else None,
                genre.strip(),
                description.strip(),
                place,
                video_path,
                poster_path,
            ),
        )
    except Exception:
        remove_file(video_path)
        remove_file(poster_path)
        raise
    return {"ok": True}


@router.delete("/admin/movies/{movie_id}")
async def delete_movie(movie_id: int, _=Depends(admin_user)):
    m = await fetch_one("SELECT video_path, poster_path FROM movies WHERE id=?", (movie_id,))
    if m:
        remove_file(m["video_path"])
        remove_file(m["poster_path"])
        await execute("DELETE FROM movies WHERE id=?", (movie_id,))
    return {"ok": True}


# --- majburiy obuna kanallari

class ChannelIn(BaseModel):
    kind: str
    title: str
    url: str
    chat_id: str = ""


@router.get("/admin/channels")
async def channels(_=Depends(admin_user)):
    return await fetch_all("SELECT * FROM channels ORDER BY id DESC")


@router.post("/admin/channels")
async def add_channel(body: ChannelIn, _=Depends(admin_user)):
    if body.kind not in ("telegram", "instagram", "youtube", "other"):
        raise HTTPException(400, "Tur noto'g'ri")
    if not body.title.strip() or not body.url.strip().startswith("http"):
        raise HTTPException(400, "Nom va to'liq havola (https://...) kerak")
    chat_id = derive_chat_id(body.kind, body.url, body.chat_id)
    await execute(
        "INSERT INTO channels(kind, title, url, chat_id) VALUES(?,?,?,?)",
        (body.kind, body.title.strip(), body.url.strip(), chat_id),
    )
    # Yangi kanal qo'shildi: hamma qaytadan «Tekshirish» tugmasini bossin
    await execute("UPDATE users SET links_ok=0")
    return {"ok": True}


@router.post("/admin/channels/{cid}/toggle")
async def toggle_channel(cid: int, _=Depends(admin_user)):
    await execute("UPDATE channels SET active = 1 - active WHERE id=?", (cid,))
    return {"ok": True}


@router.delete("/admin/channels/{cid}")
async def delete_channel(cid: int, _=Depends(admin_user)):
    await execute("DELETE FROM channels WHERE id=?", (cid,))
    return {"ok": True}


# --- reklama bannerlari

@router.get("/admin/banners")
async def admin_banners(_=Depends(admin_user)):
    return await fetch_all("SELECT * FROM banners ORDER BY id DESC")


@router.post("/admin/banners")
async def add_banner(
    media: UploadFile = File(...),
    link: str = Form(""),
    _=Depends(admin_user),
):
    ext = Path(media.filename or "").suffix.lower()
    media_type = "video" if ext in VIDEO_EXT else "image"
    path = await save_upload(media, "banners", VIDEO_EXT | IMAGE_EXT)
    await execute(
        "INSERT INTO banners(media_path, media_type, link) VALUES(?,?,?)",
        (path, media_type, link.strip()),
    )
    return {"ok": True}


@router.post("/admin/banners/{bid}/toggle")
async def toggle_banner(bid: int, _=Depends(admin_user)):
    await execute("UPDATE banners SET active = 1 - active WHERE id=?", (bid,))
    return {"ok": True}


@router.delete("/admin/banners/{bid}")
async def delete_banner(bid: int, _=Depends(admin_user)):
    b = await fetch_one("SELECT media_path FROM banners WHERE id=?", (bid,))
    if b:
        remove_file(b["media_path"])
        await execute("DELETE FROM banners WHERE id=?", (bid,))
    return {"ok": True}


# --- sozlamalar va xabar yuborish

class SettingsIn(BaseModel):
    welcome_text: str
    force_sub: bool


@router.get("/admin/settings")
async def get_settings(_=Depends(admin_user)):
    return {
        "welcome_text": await get_setting("welcome_text", ""),
        "force_sub": (await get_setting("force_sub", "1")) == "1",
    }


@router.post("/admin/settings")
async def save_settings(body: SettingsIn, _=Depends(admin_user)):
    if not body.welcome_text.strip():
        raise HTTPException(400, "Xush kelibsiz matni bo'sh bo'lmasin")
    await set_setting("welcome_text", body.welcome_text.strip())
    await set_setting("force_sub", "1" if body.force_sub else "0")
    return {"ok": True}


class BroadcastIn(BaseModel):
    text: str


async def do_broadcast(text: str):
    rows = await fetch_all("SELECT id FROM users WHERE blocked=0")
    sent = 0
    for r in rows:
        try:
            await bot.send_message(r["id"], text)
            sent += 1
        except Exception:
            pass
        await asyncio.sleep(0.05)
    logging.info("Xabar yuborildi: %s / %s", sent, len(rows))


@router.post("/admin/broadcast")
async def broadcast(body: BroadcastIn, tasks: BackgroundTasks, _=Depends(admin_user)):
    if not body.text.strip():
        raise HTTPException(400, "Matn bo'sh")
    count = await fetch_one("SELECT COUNT(*) AS c FROM users WHERE blocked=0")
    tasks.add_task(do_broadcast, body.text.strip())
    return {"started": count["c"]}
