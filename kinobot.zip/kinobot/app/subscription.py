import time

from .database import fetch_all, fetch_one, get_setting

_cache: dict[int, float] = {}


async def subscription_ok(bot, user_id: int, use_cache: bool = False) -> bool:
    """Foydalanuvchi majburiy obunani bajarganmi?

    - Telegram kanal/guruh: getChatMember orqali haqiqatan tekshiriladi
      (bot o'sha kanalda ADMIN bo'lishi kerak).
    - Instagram/YouTube/boshqa: tekshirib bo'lmaydi, foydalanuvchi
      «Tekshirish» tugmasini bosgani yetarli (links_ok).
    """
    if await get_setting("force_sub", "1") != "1":
        return True

    channels = await fetch_all("SELECT * FROM channels WHERE active=1")
    if not channels:
        return True

    if use_cache:
        t = _cache.get(user_id)
        if t and time.time() - t < 60:
            return True

    user = await fetch_one("SELECT links_ok FROM users WHERE id=?", (user_id,))
    links_ok = bool(user and user["links_ok"])

    for ch in channels:
        if ch["kind"] == "telegram" and ch["chat_id"]:
            try:
                member = await bot.get_chat_member(ch["chat_id"], user_id)
                if member.status in ("left", "kicked"):
                    return False
            except Exception:
                # Bot kanalda admin emas yoki kanal topilmadi: o'tkazib yuboramiz
                continue
        elif not links_ok:
            return False

    _cache[user_id] = time.time()
    return True
