import hashlib
import hmac
import json
import time
from urllib.parse import parse_qsl

from fastapi import Depends, Header, HTTPException

from .config import ADMIN_IDS, BOT_TOKEN


def validate_init_data(init_data: str):
    """Telegram mini ilovadan kelgan initData haqiqiyligini tekshiradi."""
    try:
        pairs = dict(parse_qsl(init_data, keep_blank_values=True))
        received = pairs.pop("hash", None)
        if not received:
            return None
        check = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
        secret = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
        calc = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calc, received):
            return None
        if time.time() - int(pairs.get("auth_date", "0")) > 86400:
            return None
        return json.loads(pairs["user"])
    except Exception:
        return None


async def current_user(x_init_data: str = Header(default="")):
    user = validate_init_data(x_init_data)
    if not user:
        raise HTTPException(status_code=401, detail="auth")
    return user


async def admin_user(user=Depends(current_user)):
    if user["id"] not in ADMIN_IDS:
        raise HTTPException(status_code=403, detail="Faqat admin uchun")
    return user
